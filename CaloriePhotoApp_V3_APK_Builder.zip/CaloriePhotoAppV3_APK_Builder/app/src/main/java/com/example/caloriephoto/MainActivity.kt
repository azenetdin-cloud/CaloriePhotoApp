package com.example.caloriephoto

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.view.Gravity
import android.widget.*
import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.*

data class MealEntry(
    val date: String,
    val items: String,
    val kcal: Int,
    val protein: Double,
    val fat: Double,
    val carbs: Double
)

class MainActivity : Activity() {
    private val client = OkHttpClient()
    private val prefs by lazy { getSharedPreferences("meals", MODE_PRIVATE) }
    private lateinit var imageView: ImageView
    private lateinit var resultView: TextView
    private lateinit var keyInput: EditText
    private lateinit var analyzeButton: Button
    private var bitmap: Bitmap? = null
    private var lastResult: MealEntry? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showMain()
    }

    private fun showMain() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 24)
        }
        scroll.addView(content)

        content.addView(TextView(this).apply {
            text = "🍎 Калории по фото"
            textSize = 28f
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 12)
        })

        val history = Button(this).apply {
            text = "📖 История питания"
            setOnClickListener { showHistory() }
        }
        content.addView(history, LinearLayout.LayoutParams(-1, 60))

        imageView = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_menu_gallery)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        content.addView(imageView, LinearLayout.LayoutParams(-1, 340))

        val choose = Button(this).apply {
            text = "🖼 Выбрать фото"
            setOnClickListener { choosePhoto() }
        }
        content.addView(choose, LinearLayout.LayoutParams(-1, 60))

        val camera = Button(this).apply {
            text = "📷 Сделать фото"
            setOnClickListener { takePhoto() }
        }
        content.addView(camera, LinearLayout.LayoutParams(-1, 60))

        keyInput = EditText(this).apply {
            hint = "Gemini API key"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(true)
            setText(prefs.getString("api_key", ""))
        }
        content.addView(keyInput, LinearLayout.LayoutParams(-1, 60))

        analyzeButton = Button(this).apply {
            text = "🔎 Распознать и посчитать"
            isEnabled = false
            setOnClickListener { analyze() }
        }
        content.addView(analyzeButton, LinearLayout.LayoutParams(-1, 64))

        resultView = TextView(this).apply {
            text = "Выберите фотографию еды."
            textSize = 18f
            setPadding(8, 22, 8, 8)
        }
        content.addView(resultView)

        val save = Button(this).apply {
            text = "💾 Сохранить в историю"
            isEnabled = false
            tag = "save"
            setOnClickListener { saveLastResult() }
        }
        content.addView(save, LinearLayout.LayoutParams(-1, 60))

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun choosePhoto() {
        startActivityForResult(Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI), 12)
    }

    private fun takePhoto() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 10)
            return
        }
        startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE), 11)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        bitmap = if (requestCode == 11) {
            data.extras?.get("data") as? Bitmap
        } else {
            val uri = data.data ?: return
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
        }
        bitmap?.let {
            imageView.setImageBitmap(it)
            analyzeButton.isEnabled = true
            resultView.text = "Фото загружено. Нажмите «Распознать и посчитать»."
        }
    }

    private fun analyze() {
        val b = bitmap ?: return
        val key = keyInput.text.toString().trim()
        if (key.isEmpty()) {
            resultView.text = "Введите Gemini API key."
            return
        }
        prefs.edit().putString("api_key", key).apply()
        analyzeButton.isEnabled = false
        resultView.text = "⏳ Анализирую фото…"
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val json = callGemini(key, b)
                val entry = parseEntry(json)
                lastResult = entry
                withContext(Dispatchers.Main) {
                    resultView.text = formatEntry(entry)
                    analyzeButton.isEnabled = true
                    findSaveButton()?.isEnabled = true
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    resultView.text = "❌ Ошибка: ${e.message ?: "анализ не выполнен"}"
                    analyzeButton.isEnabled = true
                }
            }
        }
    }

    private fun findSaveButton(): Button? {
        val root = window.decorView
        return findButton(root)
    }

    private fun findButton(v: android.view.View): Button? {
        if (v is Button && v.text.toString().contains("Сохранить")) return v
        if (v is android.view.ViewGroup) for (i in 0 until v.childCount) findButton(v.getChildAt(i))?.let { return it }
        return null
    }

    private fun parseEntry(json: JSONObject): MealEntry {
        val items = json.getJSONArray("items")
        val names = mutableListOf<String>()
        for (i in 0 until items.length()) {
            val x = items.getJSONObject(i)
            names.add("${x.getString("name")} (${x.getInt("estimated_grams")} г)")
        }
        return MealEntry(
            SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date()),
            names.joinToString(", "),
            json.getInt("total_kcal"),
            json.getDouble("total_protein_g"),
            json.getDouble("total_fat_g"),
            json.getDouble("total_carbs_g")
        )
    }

    private fun formatEntry(e: MealEntry): String =
        "🍽 ${e.items}\n\n🔥 ${e.kcal} ккал\n🥩 Б: ${"%.1f".format(e.protein)} г\n🥑 Ж: ${"%.1f".format(e.fat)} г\n🍞 У: ${"%.1f".format(e.carbs)} г"

    private fun saveLastResult() {
        val e = lastResult ?: return
        val list = getHistory().toMutableList()
        list.add(0, e)
        val json = JSONArray()
        list.take(100).forEach {
            json.put(JSONObject().apply {
                put("date", it.date); put("items", it.items); put("kcal", it.kcal)
                put("protein", it.protein); put("fat", it.fat); put("carbs", it.carbs)
            })
        }
        prefs.edit().putString("history", json.toString()).apply()
        Toast.makeText(this, "Сохранено в историю", Toast.LENGTH_SHORT).show()
        findSaveButton()?.isEnabled = false
    }

    private fun getHistory(): List<MealEntry> {
        val raw = prefs.getString("history", null) ?: return emptyList()
        val a = JSONArray(raw)
        return (0 until a.length()).map {
            val x = a.getJSONObject(it)
            MealEntry(x.getString("date"), x.getString("items"), x.getInt("kcal"),
                x.getDouble("protein"), x.getDouble("fat"), x.getDouble("carbs"))
        }
    }

    private fun showHistory() {
        val entries = getHistory()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        val title = TextView(this).apply {
            text = "📖 История питания"
            textSize = 27f
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }
        root.addView(title)
        val total = entries.sumOf { it.kcal }
        root.addView(TextView(this).apply {
            text = "🔥 Всего сохранено: $total ккал\nЗаписей: ${entries.size}"
            textSize = 19f
            setPadding(8, 0, 8, 18)
        })
        val list = ListView(this)
        val rows = entries.map {
            "${it.date}\n${it.items}\n🔥 ${it.kcal} ккал · Б ${"%.1f".format(it.protein)} · Ж ${"%.1f".format(it.fat)} · У ${"%.1f".format(it.carbs)}"
        }
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, rows)
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        val clear = Button(this).apply {
            text = "🗑 Очистить историю"
            setOnClickListener {
                prefs.edit().remove("history").apply()
                Toast.makeText(this@MainActivity, "История очищена", Toast.LENGTH_SHORT).show()
                showHistory()
            }
        }
        root.addView(clear, LinearLayout.LayoutParams(-1, 60))
        val back = Button(this).apply {
            text = "← Назад"
            setOnClickListener { showMain() }
        }
        root.addView(back, LinearLayout.LayoutParams(-1, 60))
        setContentView(root)
    }

    private fun callGemini(apiKey: String, source: Bitmap): JSONObject {
        val image = scaleDown(source, 1280)
        val stream = ByteArrayOutputStream()
        image.compress(Bitmap.CompressFormat.JPEG, 82, stream)
        val b64 = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
        val prompt = """Ты анализируешь фотографию еды. Определи все видимые продукты и блюда.
Для каждого укажи name на русском, estimated_grams, kcal, protein_g, fat_g, carbs_g.
Также total_kcal, total_protein_g, total_fat_g, total_carbs_g.
Вес по фото является оценкой. Верни ТОЛЬКО JSON без Markdown:
{"items":[{"name":"...","estimated_grams":150,"kcal":80,"protein_g":0.4,"fat_g":0.2,"carbs_g":21}],"total_kcal":80,"total_protein_g":0.4,"total_fat_g":0.2,"total_carbs_g":21,"note":"..."}"""
        val parts = JSONArray()
            .put(JSONObject().put("text", prompt))
            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64)))
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", parts)))
        val request = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw Exception("HTTP ${response.code}")
            val text = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                .replace("```json", "").replace("```", "").trim()
            return JSONObject(text)
        }
    }

    private fun scaleDown(src: Bitmap, max: Int): Bitmap {
        val scale = minOf(1f, max.toFloat() / maxOf(src.width, src.height))
        return if (scale >= 1f) src else Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true)
    }
}
